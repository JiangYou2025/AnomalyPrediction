from .simple_linear_model import SimpleLinearModel

__all__ = ["SimpleLinearModel"]
